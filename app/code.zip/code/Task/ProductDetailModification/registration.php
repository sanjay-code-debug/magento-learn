<?php
/*******************************************************************************
 *
 * Copyright 2023
 * All Rights Reserved.
 ******************************************************************************/

/**
 * Task ProductDetailModification module
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(
    ComponentRegistrar::MODULE,
    'Task_ProductDetailModification',
    __DIR__
);
